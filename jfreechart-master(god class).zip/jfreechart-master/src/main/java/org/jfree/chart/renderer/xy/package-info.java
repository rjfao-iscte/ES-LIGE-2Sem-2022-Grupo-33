/**
 * Plug-in renderers for the {@link org.jfree.chart.plot.XYPlot} class.
 */
package org.jfree.chart.renderer.xy;
