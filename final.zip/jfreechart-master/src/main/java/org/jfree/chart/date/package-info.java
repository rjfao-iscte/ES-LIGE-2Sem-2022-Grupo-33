/**
 * Date support for the time series charts.
 */
package org.jfree.chart.date;
